cd home/ec2-user/ebs
npm install
npm install -g pm2
pm2 start app.js